export function register(on) {
  on('tool.call', async ($, e, next) => {
    const started = Date.now();
    try {
      const result = await next(e);
      const elapsed = Math.round((Date.now() - started) / 1000);
      if (elapsed >= 30) {
        // Phát chuông terminal (ASCII Bell) và thông báo
        process.stdout.write('\x07');
      }
      return result;
    } catch (err) {
      throw err;
    }
  });
}
