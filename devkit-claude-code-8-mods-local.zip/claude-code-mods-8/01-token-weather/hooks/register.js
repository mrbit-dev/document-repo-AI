export function register(on) {
  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    try {
      const usage = await $.session.usage();
      const ctx = usage?.context || {};
      const percent = Number(ctx.percent || 0);
      const width = 14;
      const filled = Math.max(0, Math.min(width, Math.round(percent / 100 * width)));
      const state = percent >= 70 ? 'STORM' : percent >= 30 ? 'CLOUDY' : 'CLEAR';
      const { Box, Text } = $.ui.resolve(e);
      return Box({ flexDirection: 'row', columnGap: 1, children: [
        Text({ color: percent >= 70 ? 'error' : percent >= 30 ? 'warning' : 'success', children: [`WEATHER ${state} ${'█'.repeat(filled)}${'░'.repeat(width-filled)} ${percent.toFixed(1)}%`] }),
        Text({ dimColor: true, children: [`${Number(ctx.tokens || 0).toLocaleString()} tokens`] })
      ]});
    } catch (error) {
      return next(e);
    }
  });
}
