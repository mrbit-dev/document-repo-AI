---
description: Turn a rough idea into a structured implementation prompt.
argument-hint: [rough idea]
---
Chuyển ý tưởng thô thành 4 phần: GOAL, DETAILS, DONE-WHEN, PLAN FIRST. Chỉ lập đặc tả; không sửa code và không chạy lệnh.
