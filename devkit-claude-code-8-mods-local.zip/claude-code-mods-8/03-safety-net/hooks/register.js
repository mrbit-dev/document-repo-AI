const BLOCKED = [
  /(?:cat|type|get-content|readfile)\b[^\n]*\.env(?:\b|$)/i,
  /\b(drop|truncate)\s+(table|database)\b/i,
  /\b(curl|wget)\b[^\n]*\|\s*(sh|bash|zsh|iex)/i
];
const cmd = e => String(e?.command || e?.input?.command || e?.input?.cmd || '');
export function register(on) {
  on('tool.call', async ($, e, next) => {
    const command = cmd(e);
    if (BLOCKED.some(re => re.test(command))) return { deny: `[DEVKIT SAFETY NET] Blocked unsafe operation: ${command}` };
    return next(e);
  });
}
