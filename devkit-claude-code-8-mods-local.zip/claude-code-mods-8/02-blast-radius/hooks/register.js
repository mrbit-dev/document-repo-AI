const DANGEROUS = [
  /\brm\s+-[^\n]*[rf]/i, /\bRemove-Item\b[^\n]*-(Force|Recurse)/i,
  /\bgit\s+reset\s+--hard\b/i, /\bgit\s+clean\s+-[^\n]*f/i,
  /\bgit\s+push\s+[^\n]*--force\b/i, /\b(drop|truncate)\s+(database|table)/i,
  /\b(curl|wget)\b[^\n]*\|\s*(sh|bash|zsh)/i
];
const cmd = e => String(e?.command || e?.input?.command || e?.input?.cmd || '');
export function register(on) {
  on('tool.call', async ($, e, next) => {
    const command = cmd(e);
    if (DANGEROUS.some(re => re.test(command))) return { deny: `[DEVKIT BLAST RADIUS] Blocked dangerous command: ${command}` };
    return next(e);
  });
}
