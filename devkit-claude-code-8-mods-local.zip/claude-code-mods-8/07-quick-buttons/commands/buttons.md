---
description: Show reusable safe development actions.
argument-hint: [action]
---
Nếu người dùng truyền action, thực hiện đúng action đó: explain, test, checkpoint, changed, bugs, hoặc next. Nếu không truyền, liệt kê 6 lựa chọn và chờ người dùng chọn. Không tự commit hoặc xoá file.
