---
description: Review current git diff step by step.
---
Hãy chạy `git diff --stat` và `git diff`, sau đó giải thích từng nhóm thay đổi theo thứ tự. Không sửa file và không commit.
