# DEVKIT AI — 8 Claude Code Mods/Commands (Local Pack)

Đây là bộ local do DEVKIT AI tạo theo nội dung file guide. Các đường dẫn GitHub trong guide đã được kiểm tra và không tồn tại trong marketplace hiện tại, nên không dùng lệnh `github:...`.

## Cách validate

```bash
claude plugin validate ./01-token-weather
claude plugin validate ./02-blast-radius
# ... từng thư mục còn lại
```

## Cách chạy một mod hook

```bash
claude --plugin-dir /path/to/claude-code-mods-8/02-blast-radius
```

## Cài command custom vào project

Các mục `05`–`08` dùng Claude Code slash commands, không phải runtime hook. Copy thư mục `commands/` của plugin vào project `.claude/commands/` hoặc dùng plugin local theo tài liệu phiên bản Claude Code đang chạy.

## Phân loại trung thực

- `01`, `06`: ý tưởng dựa trên guide; UI/replay phụ thuộc API runtime.
- `02`, `03`, `04`: custom hooks/prototype, cần test runtime.
- `05`, `07`, `08`: custom slash commands, không phải Anthropic Official Mods.
- Không mục nào được gắn nhãn Anthropic Official trong source.
